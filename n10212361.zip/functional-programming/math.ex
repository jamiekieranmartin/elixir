defmodule Math do
  def sum(a, b) do
    a + b
  end

  # Math.sum(2, 3) => 5

  def square(a), do: a * a
  # Math.square(2) => 4
end
