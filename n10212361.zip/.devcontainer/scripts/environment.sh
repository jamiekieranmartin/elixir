cat >> "/home/user/.bashrc" << EOL
# environment variables 
EOL
